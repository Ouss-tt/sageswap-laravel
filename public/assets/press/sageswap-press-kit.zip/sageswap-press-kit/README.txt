SAGESWAP - PRESS KIT
====================

Contents
--------
sageswap-mark.png       Primary mark, 600 x 600, transparent
sageswap-mascot.png     Full mascot, 1170 x 1787, transparent

Brand colours
-------------
Void Black     #0A0A0A
Sage Acid      #C4EF20
Signal White   #FFFFFF

Usage
-----
Do not recolour, rotate, stretch or add effects to the mark.
Keep clear space of at least 25% of the mark's height on all sides.
Place the mark on #0A0A0A or #FFFFFF wherever possible.

Questions: Press@SageSwap.io
